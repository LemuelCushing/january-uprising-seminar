

 This font is FREEWARE

 http://www.geocities.co.jp/SiliconValley/1286/
----------------------------------------
 copyright 2001 demonhill all rights reserved